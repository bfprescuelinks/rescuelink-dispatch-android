# RescueLink Dispatch

Dedicated Android command app for authorized RescueLink dispatchers and responders.

## Capabilities

- Secure Google sign-in and server-controlled role verification
- Real-time emergency queue and incident history
- Live-moving citizen GPS, accuracy, speed, heading, and update time
- OpenStreetMap display and turn-by-turn handoff to Google Maps
- Call reporter, acknowledge, dispatch, and close incident controls

## Security

The signed-in Firebase user must have a `users/{uid}` document whose `role` is `dispatcher`, `responder`, or `admin`. Never allow a client to assign its own role.

## Android configuration

Use package ID `com.rescuelink.dispatch`. Register that Android app in Firebase project `rescuelink-bfp`, enable Google sign-in, add its SHA-1/SHA-256 fingerprints, and place the generated `google-services.json` in `android/app/` before producing a distributable build.
