import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    if (kIsWeb) {
      return const FirebaseOptions(
        apiKey: 'AIzaSyDOizsi2Rws-rQDzdRfQnhVFHI1Qu6zw4Y',
        appId: '1:1066081578301:web:5a4f83492e452a999cc216',
        messagingSenderId: '1066081578301',
        projectId: 'rescuelink-bfp',
        authDomain: 'rescuelink-bfp.firebaseapp.com',
        storageBucket: 'rescuelink-bfp.firebasestorage.app',
      );
    }
    return const FirebaseOptions(
      apiKey: 'AIzaSyDOizsi2Rws-rQDzdRfQnhVFHI1Qu6zw4Y',
      appId: '1:1066081578301:android:58d07f6022a729437e2954',
      messagingSenderId: '1066081578301',
      projectId: 'rescuelink-bfp',
      storageBucket: 'rescuelink-bfp.firebasestorage.app',
    );
  }
}
